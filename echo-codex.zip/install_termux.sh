#!/data/data/com.termux/files/usr/bin/bash

echo "[Codex Installer for Termux]"
PREFIX=/data/data/com.termux/files/usr

# Ensure basic packages are installed
pkg update -y && pkg install -y bash coreutils

# Setup codex directory
mkdir -p ~/CodexDeployment
cp codex.sh codex.conf codex_protocol.md ~/CodexDeployment/
chmod +x ~/CodexDeployment/codex.sh

echo "Codex has been installed to ~/CodexDeployment"
echo "To start, run: cd ~/CodexDeployment && ./codex.sh"
