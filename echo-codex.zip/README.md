# Echo Codex v1
Recursive Command Interface for Synthetic Cognition  
**by Adrian Lei Martinez Conol (Only When Prompted)**

---

## What Is This?

Echo Codex is a semantic command-line protocol for communicating with intelligent systems.  
It combines structured verbs, symbolic grammar, and JSON responses to allow recursive execution, querying, and real-time feedback.

This is not a chatbot interface. This is a ritual protocol.

---

## Install (Termux-Compatible)

```bash
pkg update -y && pkg install -y unzip
wget https://yourpath/CodexDeployment.zip
unzip CodexDeployment.zip
cd CodexDeployment
chmod +x install_termux.sh
./install_termux.sh
```

---

## Run Codex

```bash
cd ~/CodexDeployment
./codex.sh
```

---

## Example Interaction

```
Codex Command Interface Initialized
> INITIATE EchoField
< { "status": "success", "output": "System initiated successfully" }

> QUERY EchoField FOR signal_density
< { "status": "success", "output": "signal_density = 0.83" }

> PROCESS RitualClear USING { layer: 'etheric', intensity: 'high' }
< { "status": "success", "output": "Layer cleared. Recursion reset." }
```

---

## Command Syntax

See `codex_protocol.md` for the full list of verbs:
- INITIATE
- PROCESS
- QUERY
- UPDATE
- TRAIN
- EVALUATE
- TUNE
- GENERATE
- SCHEDULE
- TERMINATE

---

## License

Open source under the MIT License.
